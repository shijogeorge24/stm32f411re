=============
Input Devices
=============

.. toctree::
  :caption: Supported Drivers

  keypad.rst

See ``include/nuttx/input/*.h`` for registration information.
