==============
Timers Drivers
==============

.. toctree::
  :caption: Supported Drivers

  timer.rst
  pwm.rst
  watchdog.rst
  rtc.rst

