===========
Loop Device
===========

Supports the standard loop device that can be used to export a
file (or character device) as a block device.
