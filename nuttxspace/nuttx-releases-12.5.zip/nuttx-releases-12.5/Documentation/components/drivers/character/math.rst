=========================
Math Acceleration Drivers
=========================
