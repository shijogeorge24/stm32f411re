=============
``ramdisk.c``
=============

Can be used to set up a block of memory or (read-only) FLASH as
a block driver that can be mounted as a file system.  See
include/nuttx/drivers/ramdisk.h.
