====================
Audio Device Drivers
====================

See ``include/nuttx/audio/audio.h`` for interface definitions.
See also the audio subsystem at ``nuttx/audio/``.
