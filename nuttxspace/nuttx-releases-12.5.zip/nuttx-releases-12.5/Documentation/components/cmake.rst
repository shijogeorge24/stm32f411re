=============
CMake Support
=============

In the future this page will contain details about the CMake build system
support in NuttX.
