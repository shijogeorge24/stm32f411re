============================
``wapi`` WAPI (Wireless API)
============================

One can provide use ``wapi`` to connect to Access Points, configure an
Access Point, set Wi-Fi related configurations and get information about it.

Currently, ``wapi`` is the only interface provided to handle Wi-Fi networking
from the userspace.

.. toctree::
  :maxdepth: 2
  :caption: Contents

  commands.rst
  wireless.rst
