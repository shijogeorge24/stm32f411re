===================================================
``nimble`` Apache NimBLE (BLE host-layer) for NuttX
===================================================

This application will build nimBLE stack (host-only) as a library/application
in NuttX.

.. toctree::
  :maxdepth: 2
  :caption: Contents

  porting.rst
