=============================
``embedlog`` Embedlog Library
=============================

Highly configurable logger for embedded devices. Documentation and
more info available on: https://embedlog.bofc.pl
