====================================
``minibasic`` Mini Basic Interpreter
====================================

The Mini Basic implementation at ``apps/interpreters`` derives from version ``1.0``
by Malcolm McLean, Leeds University, and was released under the Creative Commons
Attibution license. I am not legal expert, but this license appears to be
compatible with the NuttX BSD license see:
https://creativecommons.org/licenses/. I, however, cannot take responsibility
for any actions that you might take based on my understanding. Please use your
own legal judgement.
