=============
``smtp`` SMTP
=============

Simple Mail Transfer Protocol (SMTP) client. See ``apps/include/netutils/smtp.h``
for interface information.
