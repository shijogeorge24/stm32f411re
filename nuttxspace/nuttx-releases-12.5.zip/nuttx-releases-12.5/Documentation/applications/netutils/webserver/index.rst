============================
``webserver`` uIP web server
============================

HTTP web server. See ``apps/include/netutils/httpd.h`` for interface information.
