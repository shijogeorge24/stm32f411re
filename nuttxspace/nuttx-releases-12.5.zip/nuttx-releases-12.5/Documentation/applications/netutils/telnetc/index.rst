=================================
``telnetc`` Telnet client library
=================================

This is a port of libtelnet to NuttX. This is a public domain
Telnet client library available from https://github.com/seanmiddleditch/libtelnet
modified for use with NuttX.

Original Authors: Sean Middleditch <sean@sourcemud.org>, Jack Kelly
<endgame.dos@gmail.com> and Katherine Flavel <kate@elide.org>
