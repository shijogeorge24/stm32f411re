=====================
``dhcpc`` DHCP client
=====================

Dynamic Host Configuration Protocol (DHCP) client. See
``apps/include/netutils/dhcpc.h`` for interface information.
