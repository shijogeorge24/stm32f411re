===================
``esp8266`` ESP8266
===================

An ESP8266 networking layer contributed by Pierre-Noel Bouteville.
