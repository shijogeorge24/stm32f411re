=====================
``tftpc`` TFTP client
=====================

TFTP client. See ``apps/include/netutils/tftp.h`` for interface information.
