===================
``ftpd`` FTP server
===================

FTP server. See ``apps/include/netutils/ftpd.h`` for interface information.
