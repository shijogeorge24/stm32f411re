==========================
``xmlrpc`` XML RPC library
==========================

The Embeddable Lightweight XML-RPC Server discussed at
http://www.drdobbs.com/web-development/an-embeddable-lightweight-xml-rpc-server/184405364
