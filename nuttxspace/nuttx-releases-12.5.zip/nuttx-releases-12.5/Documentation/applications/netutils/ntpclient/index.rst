========================
``ntpclient`` NTP client
========================

This is a fragmentary NTP client. It neither well-tested nor
mature nor complete at this point in time.
