============================
``webclient`` uIP web client
============================

HTTP web client. See ``apps/include/netutils/webclient.h`` for interface information.

