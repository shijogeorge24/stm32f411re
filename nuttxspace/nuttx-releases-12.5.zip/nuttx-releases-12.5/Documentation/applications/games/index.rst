=====
Games
=====

NuttX is not only an RTOS, it is a rich ecosystem with much fun.
And for many people fun is related to games! So let's play!

Here you will find the list of games currently supported by NuttX.

An interesting fact is that originally NuttX had the Traveler game.
It is a raycasting game that Greg Nutt developed from scratch, similar
to Doom in many ways. That game is not part of Apache NuttX.

.. toctree::
   :glob:
   :maxdepth: 1
   :titlesonly:
   :caption: Contents

   */index*
