=======================
``trace`` Trace command
=======================

See https://nuttx.apache.org/docs/latest/guides/tasktraceuser.html
