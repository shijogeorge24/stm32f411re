===========================================
``fboverlay`` Framebuffer overlay test tool
===========================================

Framebuffer overlay test tool.
