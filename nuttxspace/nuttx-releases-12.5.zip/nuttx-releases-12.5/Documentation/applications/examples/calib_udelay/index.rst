=============================================
``calib_udelay`` Calibration tool for udelay
=============================================

Calibration tool for udelay.
