===================================
``smps`` Switched-Mode Power Supply
===================================

This is a SMPS (Switched-mode power supply) driver example application.
