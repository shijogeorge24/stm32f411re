======================================
``modbusmaster`` Modbus Master example
======================================

TODO
