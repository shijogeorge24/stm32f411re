========================
``cpuhog`` Keep CPU Busy
========================

Attempts to keep the system busy by passing data through a pipe in loop back
mode. This may be useful if you are trying run down other problems that you
think might only occur when the system is very busy.
