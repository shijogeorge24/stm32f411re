=============================
``embedlog`` embedlog example
=============================

embedlog example.
