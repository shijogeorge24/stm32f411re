=============================
``pty_test`` Pseudo-Terminals
=============================

A test of NuttX pseudo-terminals. Provided by Alan Carvalho de Assis.
