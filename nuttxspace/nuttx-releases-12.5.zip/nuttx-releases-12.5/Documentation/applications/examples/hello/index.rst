=====================
``hello`` Hello World
=====================

This is the mandatory, "Hello, World" example. It is little more than
``examples/null`` with a single ``printf`` statement. Really useful only for
bringing up new NuttX architectures.

- ``CONFIG_NSH_BUILTIN_APPS`` – Build the "Hello, World" example as an NSH
  built-in application.
