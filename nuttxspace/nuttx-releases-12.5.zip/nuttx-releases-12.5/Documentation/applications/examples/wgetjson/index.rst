====================================
``wgetjson`` GET JSON Using ``wget``
====================================

Uses ``wget`` to get a JSON encoded file, then decodes the file.

- ``CONFIG_EXAMPLES_WDGETJSON_MAXSIZE`` – Max. JSON Buffer Size.
- ``CONFIG_EXAMPLES_EXAMPLES_WGETJSON_URL`` – ``wget`` URL
