=================================
``slcd`` Alphanumeric Segment LCD
=================================

A simple test of alphanumeric, segment LCDs (SLCDs).

- ``CONFIG_EXAMPLES_SLCD`` – Enable the SLCD test
