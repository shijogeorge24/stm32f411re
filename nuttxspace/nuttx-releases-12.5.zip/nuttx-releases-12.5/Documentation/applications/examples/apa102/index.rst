==========================================
``apa102`` Rainbow on ``APA102`` LED Strip
==========================================

Rainbow example for ``APA102`` LED Strip.
