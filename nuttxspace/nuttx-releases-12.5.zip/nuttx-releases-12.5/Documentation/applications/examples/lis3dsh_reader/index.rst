============================================
``lis3dsh_reader`` ``LIS3DSH`` Accelerometer
============================================

A simple reader example for the ``LIS3DSH`` acceleration sensor as found on
STM32F4Discovery rev. C.
