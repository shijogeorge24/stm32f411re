================================
``cordic`` CORDIC driver example
================================

A simple test of the CORDIC character driver.
