==============================
``abntcodi`` ABNT CODI example
==============================

ABNT CODI example
