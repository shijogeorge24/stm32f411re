=============================
``buttons`` Read GPIO Buttons
=============================

Buttons driver example.
