==============================================
``configdata`` Config Data example / unit test
==============================================

This is a Unit Test for the MTD configuration data driver.
