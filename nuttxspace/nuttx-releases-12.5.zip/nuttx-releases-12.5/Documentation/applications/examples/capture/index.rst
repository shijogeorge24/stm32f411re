===============================
``capture`` PWM Capture example
===============================

PWM Capture example.
