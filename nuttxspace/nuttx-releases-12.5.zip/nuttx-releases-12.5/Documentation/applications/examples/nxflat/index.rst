========================
``nxflat`` NXFLAT Binary
========================

This example builds a small NXFLAT test case. This includes several test
programs under ``examples/nxflat`` tests. These tests are build using the NXFLAT
format and installed in a ROMFS file system. At run time, each program in the
ROMFS file system is executed. Requires ``CONFIG_NXFLAT``.
