================================
``bmi160`` BMI160 sensor example
================================

BMI160 sensor example.
