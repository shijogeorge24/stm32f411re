================================
``hello_nim`` Hello World in Nim
================================

Hello World in Nim.
