============================
``gpio`` GPIO Read and Write
============================

A simple ``test/example`` of the NuttX GPIO driver.
