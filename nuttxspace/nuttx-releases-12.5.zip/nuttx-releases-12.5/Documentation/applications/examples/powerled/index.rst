====================================
``powerled`` Powerled driver example
====================================

This is a powerled driver example application. This application support three
operation modes which can be selected from NSH command line:

1. Demo mode.
2. Continuous mode.
3. Flash mode.
