============================
``rgbled`` RGB LED Using PWM
============================

This example demonstrates the use of the RGB led driver to drive an RGB LED with
PWM outputs so that all color characteristcs of RGB LED can be controlled.
