==============================================
``stat`` Test of stat(), fstat(), and statfs()
==============================================

A simple test of ``stat()``, ``fstat()``, and ``statfs()``. This is useful primarily
for bringing up a new file system and verifying the correctness of these
operations.
