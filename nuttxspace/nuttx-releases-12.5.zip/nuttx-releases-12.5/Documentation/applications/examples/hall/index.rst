===================================
``hall`` Hall effect sensor example
===================================

Hall effect sensor example.
