==================================
``hello_rust`` Hello World in Rust
==================================

Hello World in Rust.
