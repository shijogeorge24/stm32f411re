========================
``ft80x`` FT80x GUI Chip
========================

This examples has ports of several FTDI demos for the FTDI/BridgeTek FT80x GUI
chip. As an example configuration, see
``nuttx/boards/arm/stm32/viewtool-stm32f107/configs/ft80x/defconfig``.
