===================================
``battery`` Battery monitor example
===================================

Battery monitor example.
