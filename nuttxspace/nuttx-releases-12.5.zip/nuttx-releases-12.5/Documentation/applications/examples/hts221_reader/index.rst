============================================
``hts221_reader`` ``HTS221`` Humidity Sensor
============================================

A simple reader example for the ``HTS221`` humidity sensor.
