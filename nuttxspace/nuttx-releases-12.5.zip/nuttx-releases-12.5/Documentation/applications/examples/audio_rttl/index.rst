===================================
``audio_rttl`` Audio tone generator
===================================

Audio tone generator example (RTTL player).
