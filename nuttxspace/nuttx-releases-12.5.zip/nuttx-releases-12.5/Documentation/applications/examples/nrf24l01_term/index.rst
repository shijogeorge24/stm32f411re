==============================================
``nrf24l01_term`` NRF24L01 Wireless Connection
==============================================

These is a simple test of NRF24L01-based wireless connectivity. Enabled with:

- ``CONFIG_EXAMPLES_NRF24L01TERM``

Options:

- ``CONFIG_NSH_BUILTIN_APPS`` – Built as an NSH built-in applications.
