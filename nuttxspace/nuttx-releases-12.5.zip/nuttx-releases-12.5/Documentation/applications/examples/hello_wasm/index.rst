==================================
``hello_wasm`` Hello World in WASM
==================================

Hello World in WASM.
