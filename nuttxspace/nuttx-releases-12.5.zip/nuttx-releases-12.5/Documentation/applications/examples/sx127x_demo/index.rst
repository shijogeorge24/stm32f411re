============================
``sx127x_demo`` SX127X Radio
============================

This example demonstrates the use of the ``SX127X`` radio.
