=============================
``rfid_readuid`` RFID example
=============================

RFID ``READUID`` example.
