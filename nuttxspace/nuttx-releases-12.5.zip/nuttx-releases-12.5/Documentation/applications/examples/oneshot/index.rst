=========================
``oneshot`` Oneshot Timer
=========================

Simple test of a oneshot driver.
