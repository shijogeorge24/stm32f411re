========================================
``serialblaster`` Serial Blaster example
========================================

Sends a repeating pattern (the alphabet) out a serial port continuously. This
may be useful if you are trying run down other problems that you think might
only occur when the serial port usage is high.
