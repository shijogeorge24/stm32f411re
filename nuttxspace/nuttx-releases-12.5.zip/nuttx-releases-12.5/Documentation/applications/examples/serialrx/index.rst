==============================
``serialrx`` Serial RX example
==============================

Constant receives serial data. This is the complement to ``serialblaster``. This
may be useful if you are trying run down other problems that you think might
only occur when the serial port usage is high.
