====================
``dac`` Write to DAC
====================

This is a tool for writing values to DAC device.
