=======================================================
``lsm303_reader`` ``LSM303`` Accelerometer/Magnetometer
=======================================================

A simple reader example for the ``LSM303`` acc-mag sensor.
