===========================
``system`` System() example
===========================

This is a simple test of the ``system()`` command. The test simply executes this
``system`` command:

.. code-block:: C

  ret = system("ls -Rl /");
