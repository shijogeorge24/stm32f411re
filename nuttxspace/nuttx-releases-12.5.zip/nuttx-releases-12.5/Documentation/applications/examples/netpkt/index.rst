====================================
``netpkt`` ``AF_PACKET`` Raw Sockets
====================================

A test of ``AF_PACKET``, raw sockets. Contributed by Lazlo Sitzer.
