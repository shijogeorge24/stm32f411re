==================
``fb`` Framebuffer
==================

A simple test of the framebuffer character driver.
