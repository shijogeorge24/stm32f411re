===================================
``obd2`` OBD-II application example
===================================

A simple test of ``apps/canutils/libobd2``.
