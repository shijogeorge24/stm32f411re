====================================
``adjtime`` Ajdtime function example
====================================

This application demonstrates the usage of adjtime() interface used to
synchronize system clock time if its value varies from real time (usually get by
external RTC).
