==============
``json`` cJSON
==============

This example exercises the cJSON implementation at ``apps/netutils/json``. This
example contains logic taken from the cJSON project:

http://sourceforge.net/projects/cjson/

The example corresponds to SVN revision ``r42`` (with lots of changes for NuttX
coding standards). As of ``r42``, the SVN repository was last updated on
``2011-10-10`` so I presume that the code is stable and there is no risk of
maintaining duplicate logic in the NuttX repository.
