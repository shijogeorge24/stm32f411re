=============================
``i2sloop`` I2S loopback test
=============================

I2S loopback test.
