=====================================
``lua_module`` Hello World Lua module
=====================================

A Lua C module showing how to add built-in modules to the Lua interpreter.
Usage:

.. code-block:: lua

    > hello.say_hello()
    "Hello World!"
