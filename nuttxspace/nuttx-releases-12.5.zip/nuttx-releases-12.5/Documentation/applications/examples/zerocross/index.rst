==================================
``zerocross`` Zero Crossing Device
==================================

A simple test of the Zero Crossing device driver.

