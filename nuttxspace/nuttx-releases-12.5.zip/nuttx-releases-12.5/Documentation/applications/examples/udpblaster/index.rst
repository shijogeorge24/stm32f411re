==================================
``udpblaster`` UDP blaster example
==================================

This is a simple network test for stressing UDP transfers. It simply sends UDP
packets from both the host and the target and the highest possible rate.
