===================================================
``etl`` Embedded Template Library (ETL) C++ example
===================================================

Embedded Template Library (ETL) C++ example
