======================================================
``lsm6dsl_reader`` ``LSM6DSL`` Accelerometer/Gyroscope
======================================================

A simple reader example for the ``LSM6DSL`` acc-gyro sensor.
