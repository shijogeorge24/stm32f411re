=====================
``null`` NULL example
=====================

This is the do nothing application. It is only used for bringing up new NuttX
architectures in the most minimal of environments.
