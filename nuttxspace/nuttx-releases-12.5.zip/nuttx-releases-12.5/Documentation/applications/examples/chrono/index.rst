=========================================================
``chrono`` Chronometer example to use with STM32LDiscover
=========================================================

Chronometer example to use with STM32LDiscover.
