====================
``leds`` Toggle LEDs
====================

This is a simple test of the board LED driver at
``nuttx/drivers/leds/userled_*.c``.
