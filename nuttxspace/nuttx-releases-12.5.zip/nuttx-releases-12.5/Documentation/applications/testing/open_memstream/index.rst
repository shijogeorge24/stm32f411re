=============================================
``open_memstream`` - open_memstream test tool
=============================================

``CONFIG_TESTING_OPEN_MEMSTREAM=y``

Performs a basic operations with open_memstream call.

Usage::

    open_memstream_test
