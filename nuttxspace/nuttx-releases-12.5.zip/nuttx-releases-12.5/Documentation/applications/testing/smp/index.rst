===================
``smp`` SMP example
===================

This is a simple test for SMP functionality. It is basically just the pthread
barrier test with some custom instrumentation.
