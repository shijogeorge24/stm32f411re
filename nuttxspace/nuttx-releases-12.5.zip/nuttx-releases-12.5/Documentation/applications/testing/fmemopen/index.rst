=======================================
``fmemopen`` - fmemopen test tool
=======================================

``CONFIG_TESTING_FMEMOPEN_TEST=y``

Performs a basic operations with fmemopen call.

Usage::

    fmemopen_test
