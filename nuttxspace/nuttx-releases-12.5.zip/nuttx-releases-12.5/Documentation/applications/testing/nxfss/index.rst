===================================
``nxffs`` NXFFS file system example
===================================

This is a test of the NuttX NXFFS FLASH file system. This is an NXFFS stress
test and beats on the file system very hard. It should only be used in a
simulation environment! Putting this NXFFS test on real hardware will most
likely destroy your FLASH. You have been warned.
