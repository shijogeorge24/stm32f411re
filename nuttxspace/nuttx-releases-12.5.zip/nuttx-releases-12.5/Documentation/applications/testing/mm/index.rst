=============================
``mm`` Memory management test
=============================

This is a simple test of the memory manager.
