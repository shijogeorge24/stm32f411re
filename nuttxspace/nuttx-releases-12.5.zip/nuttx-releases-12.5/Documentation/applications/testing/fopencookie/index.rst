=====================================
``fopencookie`` fopencookie test tool
=====================================

``CONFIG_TESTING_SMART_TEST=y``

Performs a basic operations with fopencookie call.

Usage::

    fopencookie
